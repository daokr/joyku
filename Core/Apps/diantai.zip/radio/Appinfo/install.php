<?php
/**
 * 安装电台应用
 * @author yangweijie <yangweijiester@gmail.com>
 * @version TS3.0
 */
if(!defined('SITE_PATH')) exit();
// 头文件设置
header('Content-Type:text/html;charset=utf-8;');

$oldTypeArray = array (
	0 => array ('title' => '电台','name' => '豆瓣FM','image' => 'db.jpg','url' => 'http://douban.fm/partner/baidu/doubanradio?bd_user=419899187&bd_sig=7af6c9595491149f56b3593dfae1bf4a&canvas_pos=platform','isopen' => 1, ),
	1 => array ('title' => '电台','name' => '儿童音乐电台','image' => 'et.jpg','url' => 'http://app.baidu.com/132254?canvas_pos=platform','isopen' => 1,),
	2 => array ('title' => '电台','name' => '酷狗电台','image' => 'kg.jpg','url' => 'http://topic.kugou.com/radio/baiduNew.htm','isopen' => 1,),
	3 => array ('title' => '电台','name' => 'ting!电台','image' => 't.jpg','url' => 'http://ting.baidu.com/app/baidu/tingradio?bd_user=419899187&bd_sig=b6525ab18cda25206d9f111d9a6572c5&canvas_pos=platform','isopen' => 1,),
	4 => array ('title' => '电台','name' => '乐酷电台','image' => 'yk.jpg','url' => 'http://music.sina.com.cn/app/baidu/index.php','isopen' => 1,),
	5 => array ('title' => '电台','name' => '酷我电台','image' => 'kw.jpg','url' => 'http://player.kuwo.cn/webmusic/webdiantai/kuwoBaiduPlay.jsp','isopen' => 1,),
	6 => array ('name' => '虾米电台','title' => '虾米电台-新歌','url' => 'http://kuang.xiami.com/kuang/play/xiamiradio?bd_user=419899187&bd_sig=13e0af162ce677c9c67d927d490d3667&canvas_pos=platform','isopen' => 1,'image' => '1336400162.jpg',),
	7 => array ('name' => '多米电台','title' => '多米-好听的英文歌','url' => 'http://app.duomiyy.com/songplayer/baidu?lid=100004&canvas_pos=platform&bd_user=419899187&bd_sig=9ef35d1f41cf40b0c949d8e19cb65b65&canvas_pos=platform','isopen' => 1,'image' => '1336400799.jpg',),
	8 => array ('name' => 'NBA篮球音乐','title' => 'NBA篮球音乐','url' => 'http://www.xiami.com/kuang/appbaidu/id/536?bd_user=419899187&bd_sig=fce6f4e26dd8c181e6921e4a81527a7e&canvas_pos=platform','isopen' => 1,'image' => '1336399501.jpg',),
	9 => array ('name' => '音悦台','title' => '音悦台','url' => 'http://www.yinyuetai.com/webqq/index1','isopen' => 1,'image' => '1336401766.jpg',)
);
require_once APPS_PATH.'/radio/Common/common.php';
save_config(array('config'=>$oldTypeArray,'file'=>'old_type.php'));//保存原始数据
save_config(array('config'=>$oldTypeArray,'file'=>'type.php'));//新建数据文件