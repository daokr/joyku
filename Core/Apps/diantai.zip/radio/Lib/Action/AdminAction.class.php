<?php
tsload(APPS_PATH.'/admin/Lib/Action/AdministratorAction.class.php');
class AdminAction extends AdministratorAction{
	public $pageTitle = array();

	public function _initialize() {
		define(RADIO_PATH,APPS_PATH.'/radio');
		$this->pageTitle['index'] = '电台管理';
		$this->pageTitle['create'] = '新建电台';
		$this->pageTitle['ask'] = '使用相关';
		$this->pageTab[] = array('title'=>'电台管理','tabHash'=>'index','url'=>U('radio/Admin/index'));
		$this->pageTab[] = array('title'=>'新建电台','tabHash'=>'create','url'=>U('radio/Admin/create'));
		$this->pageTab[] = array('title'=>'使用相关','tabHash'=>'ask','url'=>U('radio/Admin/ask'));
		parent::_initialize();
	}

	//电台管理
	public function options(){
		$data = include RADIO_PATH.'/type.php';
		if($_GET['do']){
			$do = $_GET ['do'];
			switch ($do) {
				case 'change':
					$id = abs(intval($_GET['id']));
					(!empty($data[$id])) ? $data[$id]['isopen'] = ($data[$id]['isopen'] + 1) % 2 : "";
					if($this->update_cache($data))
						$this->success('更改状态成功');
					else
						$this->error('更改状态失败');
					break;
				case 'del':
					$id = abs(intval($_GET['id']));
					$img = RADIO_PATH.'/_static/images/'.$data[$id]['image'];
					unset($data[$id]);
					if($this->update_cache($data) && unlink($img))
						$this->success('删除成功');
					else
						$this->error('删除失败');
					break;
			}
		}
		if($_POST){//修改顺序
			$arrNewType = array ();
			foreach ($data as $k => $v) {
				$newId = (isset($_POST['id'.$k])) ? abs(intval($_POST['id'.$k])) : $k;
				if(!empty($arrNewType[$newId])){
					$arrNewType[] = $data[$k];
				}else{
					$arrNewType[$newId] = $data[$k];
				}
			}
			if($this->update_cache($arrNewType))
				$this->success('更改顺序成功');
			else
				$this->error('更改顺序失败');
		}
		$this->display();
	}

	//后台首页
	public function index(){
		$data = include RADIO_PATH.'/type.php';
		$this->assign('ask_url',U('radio/admin/ask','tabHash=ask'));
		$this->assign('url_path',__APP__.'/');
		$this->assign('data',$data);
		$this->display('options');
	}

	//新建电台
	public function create(){
		$data = include RADIO_PATH.'/type.php';
		$id = ($_GET['id'] !== null)? abs(intval($_GET['id'])) : '';
		if($data[$id]){
			$this->assign('id',$id);
			$this->assign('arrCurType',$data[$id]);
		}
		$this->display();
	}

	//使用相关
	public function ask(){
		$this->display();
	}

	//更新缓存
	public function update_cache($param){
		ksort($param);
		require_once RADIO_PATH.'/Common/common.php';
		return save_config(array(
			'config'=>$param,
			'file'=>'type.php'
		));
	}

	//添加和编辑表单
	public function add_edit(){
		$data = include RADIO_PATH.'/type.php';
		$newType['name'] = htmlspecialchars($_POST['name']);
		$newType['title'] = htmlspecialchars($_POST['title']);
		$newType['url'] = htmlspecialchars($_POST['url']);
		$newType['isopen'] =1;
		if(isset($_POST['id'])){//编辑
			$id = abs(intval($_POST['id'])); 
			$newType['isopen'] = $data[$id]['isopen'];
			if(!$_FILES['image']['name']){
				$newType['image'] = $data[$id]['image'];
				$data[$id] = $newType;
				$this->update_cache($data);
				$this->success('编辑成功');
			}else{
				if($newType['image'] = $this->upload_image($_FILES['image'])){
					@unlink(RADIO_PATH.'/_static/images/'.$data[$id]['image']);
					$data[$id] = $newType;
					$this->update_cache($data);
					$this->success('编辑成功');
				}else{
					$this->error('上传图片失败，编辑失败，请检查目录权限');
				}
			}
		}else{//添加
			if(!$newType['name'] || !$newType['title'] || !$newType['url'])
				$this->error(请填写所有表单项);
		
			($_FILES['image']['name']) ? $fileName = $this->upload_image($_FILES['image']) : "";
			if(empty($fileName)){
				$this->error('上传图片失败，添加电台失败');
			}
			$newType['image'] = $fileName;
			$data[] = $newType;
			$data = $this->update_cache($data);
			$this->success('添加电台成功');
		}
	}

	//上传图片
	public function upload_image($param){
		if(is_uploaded_file($param['tmp_name'])){
			$suffixArray = explode('.', $param['name']);
			$suffix = array_pop($suffixArray);
			$suffix = strtolower($suffix);
			$fileName = time().".".$suffix;
			$suffixs =	array('jpg','png','gif','jpeg');
			$dir = RADIO_PATH.'/_static/images/'.$fileName;
			if (in_array($suffix,$suffixs) && !move_uploaded_file($param['tmp_name'],$dir))
				return "";
			return $fileName;
		}
	}
}