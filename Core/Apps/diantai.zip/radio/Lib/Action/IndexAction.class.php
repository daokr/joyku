<?php
/**
 * IndexAction
 * radio
 */
class IndexAction extends Action {
	public function _initialize() {

	}

	protected $app = null;
	
	/**
	* index
	* 用于显示
	*/
	public function index() {
		$type = (isset($_GET['id'])) ? abs(intval($_GET ['id'])) :(($_COOKIE['radio_type'])?$_COOKIE['radio_type']:0);
		$result = include APPS_PATH.'/radio/type.php';
		$openArray= array();
		foreach ($result as $k=>$v){
			($v['isopen'] == 1) ? $openArray[$k] = $v : ""; 
		}
		$arrAllType = $result = $openArray;
		if(empty($result[$type])){
			$type = array_rand($result);
		}
		$curType = $result[$type];
		if(isset($_GET['id']))	setcookie('radio_type',$type,time()+60*60*24*30);
		$title = (empty ( $curType )) ? '电台' : $curType ['title'];
		$this->setTitle($title);
		$this->assign('arrAllType',$arrAllType);
		$this->assign('curType',$curType);
		$this->display();
	}
}