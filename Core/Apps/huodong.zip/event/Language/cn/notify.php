<?php 
return  array(
	'event_add'   => array(
		'title' => '{actor}发起了一个活动【'.$title.'】',
		'body'  =>'&nbsp;&nbsp;&nbsp;&nbsp;只允许TA关注的人来参加。<br /> <div class="quote"><p><span class="quoteR">'.$content.'</span></p></div><br /><a href="'.$url.'" target="_blank">去看看</a>',
	),
);
?>