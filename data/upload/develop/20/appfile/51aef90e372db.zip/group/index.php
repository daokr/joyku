<?php
//定义项目名称和路径
define('APP_NAME', 'App');
define('APP_PATH', './App/');
define('APP_DEBUG',TRUE);
// 加载框架入口文件
require( "../ThinkPHP/ThinkPHP.php");